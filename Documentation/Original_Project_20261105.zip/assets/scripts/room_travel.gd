extends Node

var _is_changing_room: bool = false


func go_to_room(scene_path: String, spawn_name: StringName) -> void:
	if _is_changing_room:
		return

	if scene_path.is_empty() or spawn_name.is_empty():
		push_error(
			"Room travel: target room and target spawn are required."
		)
		return

	if not ResourceLoader.exists(scene_path, "PackedScene"):
		push_error(
			"Room travel: scene not found: %s" % scene_path
		)
		return

	_is_changing_room = true
	_perform_change.call_deferred(scene_path, spawn_name)


func _perform_change(
	scene_path: String,
	spawn_name: StringName
) -> void:
	var packed_room := load(scene_path) as PackedScene

	if packed_room == null:
		push_error(
			"Room travel: unable to load: %s" % scene_path
		)
		_is_changing_room = false
		return

	var next_room := packed_room.instantiate()

	var player := next_room.get_node_or_null(
		"Player"
	) as CharacterBody2D

	var spawn := next_room.get_node_or_null(
		NodePath("Spawns/" + String(spawn_name))
	) as Marker2D

	if player == null or spawn == null:
		push_error(
			"Room travel: target room requires Player and Spawns/%s."
			% spawn_name
		)
		next_room.free()
		_is_changing_room = false
		return

	var tree := get_tree()
	var change_error := tree.change_scene_to_node(next_room)

	if change_error != OK:
		push_error(
			"Room travel: %s" % error_string(change_error)
		)
		next_room.free()
		_is_changing_room = false
		return

	await tree.scene_changed

	player.global_position = spawn.global_position
	player.velocity = Vector2.ZERO
	player.reset_physics_interpolation()

	var camera := player.get_node_or_null(
		"Camera2D"
	) as Camera2D

	if camera != null:
		camera.reset_smoothing()
		camera.force_update_scroll()

	print(
		"Room travel: %s -> %s"
		% [scene_path, String(spawn_name)]
	)

	_is_changing_room = false
