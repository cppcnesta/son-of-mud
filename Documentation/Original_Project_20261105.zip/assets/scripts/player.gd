extends CharacterBody2D

@export var move_speed: float = 300.0
@export var jump_velocity: float = -600.0
@export var inspection_speed: float = 500.0

var inspection_mode: bool = false


func _ready() -> void:
	add_to_group(&"player")


func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("toggle_inspection"):
		inspection_mode = not inspection_mode

		motion_mode = (
			MOTION_MODE_FLOATING
			if inspection_mode
			else MOTION_MODE_GROUNDED
		)

		velocity = Vector2.ZERO

		print(
			"Inspection mode: %s"
			% ("ON" if inspection_mode else "OFF")
		)

	if inspection_mode:
		var direction := Input.get_vector(
			"move_left",
			"move_right",
			"move_up",
			"move_down"
		)

		velocity = direction * inspection_speed
	else:
		if not is_on_floor():
			velocity += get_gravity() * delta

		velocity.x = (
			Input.get_axis("move_left", "move_right")
			* move_speed
		)

		if Input.is_action_just_pressed("jump") and is_on_floor():
			velocity.y = jump_velocity

	move_and_slide()
