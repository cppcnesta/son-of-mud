extends Area2D

@export_file("*.tscn") var target_room: String = ""
@export var target_spawn: StringName = &""
@export var debug_output: bool = true


func _ready() -> void:
	body_entered.connect(_on_body_entered)

	if not InputMap.has_action(&"interact"):
		push_error(
			"Room portal: add the interact input action and bind E."
		)
		set_process(false)
		return

	var has_shape: bool = false

	for child in get_children():
		if child is CollisionShape2D:
			if child.shape != null and not child.disabled:
				has_shape = true
				break

	if not has_shape:
		push_error(
			"Room portal: %s needs an enabled CollisionShape2D with a shape."
			% name
		)

	if debug_output:
		print("Room portal ready: %s" % name)


func _process(_delta: float) -> void:
	if not Input.is_action_just_pressed("interact"):
		return

	for body in get_overlapping_bodies():
		if not body.is_in_group(&"player"):
			continue

		var travel := get_node_or_null("/root/RoomTravel")

		if travel == null or not travel.has_method(&"go_to_room"):
			push_error(
				"Room portal: register the complete RoomTravel autoload."
			)
			return

		if debug_output:
			print(
				"Room portal: %s -> %s / %s"
				% [name, target_room, target_spawn]
			)

		travel.call(
			&"go_to_room",
			target_room,
			target_spawn
		)
		return

	if debug_output:
		print("Room portal: player is outside %s." % name)


func _on_body_entered(body: Node2D) -> void:
	if debug_output and body.is_in_group(&"player"):
		print(
			"Room portal: player entered %s. Press E."
			% name
		)
