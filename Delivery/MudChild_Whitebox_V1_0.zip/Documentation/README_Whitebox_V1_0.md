# 泥之子Godot白盒V1.0交付说明

当前动作规则以Combat_Feel_Update.md为准：泥闪避后1秒、攻击后1.5秒曲线减速，攻击后摇最后0.5秒允许格挡；水格挡CD3秒，成功重置格挡CD和攻击间隔。旧版2秒线性闪避减速已停用。

旧编辑器路径中的mp_01、mp_02、mp_03现为兼容入口，内容统一继承whitebox/legacy场景。若看到迁移前生成的依赖错误弹窗，关闭弹窗并重新打开工程；本次路径修复与验证见Scene_Path_Repair.md。

已直接修改工程：`D:/GAMEOFF/mud-child-map-practice`。实际引擎为Godot4.7.2.stable.official.ed1daf0bf，渲染器为Compatibility，运行日志显示OpenGL3.3 / NVIDIA RTX4060 Laptop GPU。

## 运行入口

- 打开本工程`project.godot`，F5进入中文主菜单，选择“新流程·苏醒”“继续”或“独立测试场”。
- 主菜单：`res://assets/scenes/ui/main_menu.tscn`。
- 形态测试场：`res://assets/scenes/whitebox/tests/form_lab.tscn`，也可在流程中按F2进入。
- 主线场景：`res://assets/scenes/whitebox/levels/M01.tscn`至H03，共23个。没有T07、T08或H04～H08。
- 旧的`assets/scenes/whitebox/legacy/mp_*.tscn`和Room01保留为历史练习场景，不在新主线连接图中；全部复用唯一`assets/scripts/player/player.gd`，没有第二套玩家控制器。
- 修改前的项目备份：`Documentation/Original_Project_20261105.zip`。

## 操作

|按键|功能|
|---|---|
|A/D|左右移动|
|空格/W|跳跃；二段跳解锁后空中再按一次|
|Q|水/泥形态切换|
|Shift|闪避|
|K|格挡；松开再按才能发起下一次动作|
|J|攻击；空中按住S+J在未解锁重压下砸时为向下普通攻击|
|空中S+J|解锁后使用重压下砸|
|贴墙+朝墙方向+W|攀墙，需独立能力解锁|
|水中W/S|潜游升降，需水形态且已解锁潜游|
|E|最近发光节点或房门交互；捷径先破门，再按一次通行|
|B|测试场或M04/C03/H02落地待机时选择泥跳跃模组|
|F2|独立测试场|
|F6|只在测试场开放调试能力；不会解锁高跳升级|
|F8|重开正式流程并清除正式进度及测试覆盖|
|R|从最近休整/战斗房间入口重试|
|Esc|主菜单|

保留了原有输入项与绑定，缺少的动作已添加到project.godot。InputDefaults只作缺项补充，不清空输入映射。旧F2巡检动作绑定仍保留，但主线不提供穿越门槛的飞行巡检；F2用于测试场。

## 中文Inspector参数说明

Inspector中打开下列`.tres`；导出组名和文档说明为中文，字段名保持英文，便于代码引用。

|文件/字段|意义|单位/规则|
|---|---|---|
|assets/data/player/water.tres、mud.tres|两形态配置资源|MudFormConfig|
|move_speed|普通移动速度|px/s|
|dodge_speed / dodge_duration / dodge_cooldown|闪避速度/持续/冷却|px/s、秒|
|penalty_duration / penalty_initial_multiplier|闪避后移速惩罚时长与起始倍率|泥为1秒、0.2，曲线恢复|
|block_duration / block_single_hit|最长格挡时长/是否仅挡一次|水0.5秒且单次；泥2秒且多次|
|grants_block_bonus / block_bonus_multiplier|是否给予格挡增伤/倍率|资格不叠加，实际命中才消费|
|damage|单次基础伤害|原型暂定|
|attack_windup / attack_active / attack_recovery|前摇/有效判定/后摇|独立状态与时间，非动画调速|
|attack_reach|近战判定长度|px|
|down_attack_multiplier|空中向下攻击倍率|模组1泥形态使用强化值|
|jump_windup / jump_speed / gravity|起跳前摇/起跳速度/重力|秒、px/s、px/s²|
|constant_descent / descent_speed|是否固定下降速度/速度|仅下降阶段生效|
|terminal_speed|加速下降终端速度|px/s|
|hold_acceleration / hold_max_time|长按时减少的重力/最长延升时间|px/s²、秒|
|hold_height_cap|模组2未升级单跳高度硬上限|px|
|assets/data/player/prototype_rules.tres|全局原型规则|MudPrototypeRules|
|initial_form / initial_abilities|正式初始形态/初始能力|与测试解锁分开|
|mud_jump_module|默认泥跳模组|0为模组1，1为模组2；默认模组1不是定案|
|switch_cooldown / allow_air_switch|切换冷却/是否允许空中切换|秒/布尔|
|allow_action_cancel|动作中是否允许切形态取消|默认false；开启取消泥闪避仍发放减速|
|omnidirectional_block|是否全方向格挡|默认true；关闭则只挡正面|
|dodge_invulnerability|闪避起始无敌时间|默认0，不默认赠送无敌帧|
|upgraded_hold_height|后续独立高跳升级的高度上限接口|需high_jump_upgrade标记，主线本版不发放；后续还需配套轨迹调参|
|landing_radius / landing_damage|模组2合格落地范围与伤害|px/原型伤害|
|slam_speed / slam_damage|重压下砸速度/伤害|px/s/原型伤害|
|boss_stagger_duration / boss_vulnerability|守坑人被格挡后的僵直时长/Boss易伤倍率|秒/倍率|
|assets/data/whitebox/world.json|房间尺寸、接口、出生点、事件与文字|可编辑；场景运行时构建，不要求编辑器插件|
|主线场景room_id|该场景读取的房间数据键|保持与文件名对应|
|MudRoomPortal.requirements|能力/事件/三街区通行条件|每个接口独立|
|break_from_this_side / bidirectional_after_break|开启方向/破坏后双向通行|分别配置，当前T06侧开启且永久双向|

## 已确认规则与暂定参数

|项目|已确认|当前可调原型值/选择|
|---|---|---|
|移动|水快于泥|水360、泥280px/s|
|水闪避|短冷却、长距离|760px/s×0.28秒，冷却0.65秒|
|泥闪避|极长冷却、中距离|520px/s×0.24秒，冷却4秒|
|泥闪避后减速|1秒；最初降低80%；曲线恢复|倍率0.2→1.0，曲线恢复，切换保留|
|水格挡|最长0.5秒；最多成功1次；按住不续挡|全方向为暂定选择|
|泥格挡|按住最多2秒，可挡不同攻击；下次有效命中增伤不叠加|增伤1.6倍；同一次攻击的后续命中沿用该次倍率；打空不消费|
|攻击差异|水快、泥前摇略长后摇明显长、泥单次伤害高|水伤害10，0.08/0.10/0.16秒；泥伤害24，0.14/0.12/1.5秒，后摇可移动|
|跳跃基础|水前摇短、泥模组1前摇长|0.05秒/0.24秒，初速600、重力1600|
|水下降|上升正常，过顶点后匀速下降|下降300px/s|
|泥模组1|加速下落、终端速度、下降时向下攻击强化；普通落地无自动攻击|终端880px/s，下降时向下普通攻击1.8倍；模组2不继承该倍率|
|泥模组2|按下起跳、按住延升、松开截断；到上限才有一次落地范围攻击|延升0.24秒，单跳硬上限176px；范围150px/伤害30|
|形态切换|不刷新冷却/泥减速/跳数/增伤，不默认免费取消动作|切换冷却0.15秒；测试场可快速切换；空中纵向轨迹冻结于起跳配置|
|潜游|形态与能力标记独立|水内不允许切泥，避免水面重新实体化困住玩家；离开水体后可切换（暂定）|
|无敌与格挡方向|未定案|闪避无敌0秒；全方向格挡|
|街区谜题|三个独立征兆及完成标记|第一街区潜游；第二街区下砸；第三街区按①②③，属于白盒方案|
|供桌/休整|Boss前准备与生命之面包|E食用/休整恢复满生命；离开即不食用，数值非正式定案|
|七门器物|逐门放下七件器物，保留对应泥板/事件|本版不剥夺能力；无确认前不引入战斗惩罚|

按住泥模组2达到高度上限才保留落地伤害资格；短跳、普通跌落、撞顶、传送都不授予资格。两个模组互斥且只在安全落地待机时选择。形态切换不会改变已经开始的跳跃纵向配置。

## 能力与主线流程

1. 本原型初始水形态，格挡与切换已可用，M01提供攻击源与说明，M05前可练习格挡。
2. M05成功格挡指定占位攻击会使守坑人僵直，并提供易伤窗口。E开始挑战，战斗封锁双向门；R死亡重试未击败战斗；胜利永久开门。
3. T01入口安全节点获得二段跳，必须实际完成二段跳高台教学才开放T02；T02获得攀墙并爬到上层，才开放T03。因此T04前已获得并练习两项能力。
4. T03操作水闸，3秒洪水色块演出后退水，开放后续；可读「洪水之后」。
5. T04为锁定位置下砸/换位失衡的龙蛇占位战。墙面、侧平台和二段跳空间已保留。冲拳、合掌、抓握三套正式动作尚未制作，不将其称为已完成招式。
6. T05保留2.5H纵向空间，含塔姆图与流星雕像；向上抵达城市出口。T06黄/红功能分区使用一个场景，不生成重复房间。
7. C03与伊吉交谈、获得重压下砸；C04入口获得潜游。两个能力获取点均位于此前已有能力可达的安全地面。
8. C04池底读征兆、C05击碎裂板读雕像、C06顺序读征兆，分别写入完成标记。城市不增加解肝大祭司Boss。C07要求三个街区完成且已见伊吉。
9. C07→C08→T06→H01。T06侧E破门，再E可经捷径返回T05；首次T05无法反向开启。
10. H01一场景内从下向上登塔，按顺序经过角冠、金耳环、项链、胸饰、腰带、手镯、长袍七道门并读对应泥板。H02休整与能力应用，H03依次塔姆图、伊姆杜两阶段，之后触发真相及醒来/回去睡分支。

最新.ai的H区在导航图中向下排列；PDF叙事要求向上登塔。本版把图的上下排布解释为导航连接，在H01内部向上攀登，没有把剧情改成下潜。C08绿色/红色部分同样作为一个过渡场景。芦苇泽、高崖、眼之殿和M02下方水域只留扩展说明/数据接口，不建立额外房间或可传送边。

## 存档与模块

- Progress管理能力、街区、七道门、Boss、捷径、剧情节点、最近房间和检查点。JSON带version=1，先写临时文件再替换；路径为`user://mudchild_whitebox_v1.json`。
- 测试能力为独立覆盖层，测试场不写正式存档；F8新流程清空覆盖层。恢复正式进度后测试解锁不残留。
- RoomTravel继续提供原来的go_to_room入口，校验真实资源路径，延迟换场并定位目标Marker；额外携带生命/形态/冷却/减速/增伤资格。
- 过门清空空中落地伤害资格与速度；出生点不与触发门重合，E主动交互，抵达锁定0.45秒。
- action_state管理动作互斥；player_combat管理攻击形状、命中去重和增伤消费；attack_ledger管理敌人攻击ID去重；form_config、prototype_rules管理资源；whitebox_room调度房间数据，whitebox_geometry搭建地形，whitebox_events执行交互事件。
- 旧控制器已被唯一状态控制器替换，玩家场景路径仍是`res://assets/scenes/player/player.tscn`。未引用不存在的`res://scenes/player.tscn`。

## 验证范围与证据

已修复“下落时发起跳跃，前摇尚未结束就落地”导致的jump_speed空引用，详见`Jump_Landing_Fix.md`。待起跳配置与当前空中轨迹已分开；受伤和传送会取消待起跳请求。

资源导入日志见`import.log`；完整图形运行检查见`runtime_suite.log`与`runtime_results.json`，后续回归见`focused_suite.log`/`focused_results.json`及`final_patch_suite.log`/`final_patch_results.json`。详细结果以`Test_Report.md`为准。

这些检查是在实际Windows图形窗口、OpenGL兼容渲染器和真实Godot物理帧中执行，通过输入动作/物理键事件驱动，并非只做无头解析。主线接口检查会逐条真实换场并校验目标Marker位置；能力门槛另外从未解锁与已解锁两种状态实际移动/跳跃测试。

尚未完成：正式角色/敌人/Boss美术、三套龙蛇正式招式、动画、CG、配音、音效、敌人逃跑表现、掉落经济、正式谜题美术与平衡。剧情使用文本和色块；高跳升级只提供独立接口，没有本版主线获取点。

尚未验证：从M01开始完全由真人连续操作至双结局的手感验收、手柄、其他硬件/分辨率/帧率、导出后的独立exe。桌面自动化可观察游戏窗口，但其短按键未可靠传入，因此不把它计为人工键盘游玩通过；实际键位映射由运行时物理InputEventKey注入检查。

## 尺寸与接口

见`Room_Manifest.md`，列出23个房间的W/H建议、64px网格取整尺寸、每个接口ID、目标房间、目标出生点、本侧门/Marker坐标与条件。1152×648沿用工程未覆盖时的Godot默认基础分辨率。Boss尺寸优先满足战斗与镜头，均为可修改的白盒建议值。

注意：运行中的房间内容由whitebox_room构建，编辑器打开单个.tscn只显示房间根及room_id；运行后可在Remote树查看Player、Spawns、接口和白盒内容。直接修改world.json即可调整尺寸与接口；无需运行Python生成器。`tests/build_world.py`用于从当前基线重新生成，运行它会覆盖world.json与主线.tscn，编辑数据后请先保存副本。
